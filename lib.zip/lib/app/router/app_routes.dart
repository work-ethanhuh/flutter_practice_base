class Routes {
  static const String splash = 'splash';
  static const String dashboard = 'dashboard';
  static const String home = 'home';
  static const String homeSample = 'home_sample';
  static const String settings = 'settings';
}