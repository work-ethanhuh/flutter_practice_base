import 'package:flutter_practice_base/app/bootstrap.dart';

void main() async {
  await bootstrap();
}